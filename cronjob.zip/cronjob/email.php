<?php

require "phpmailer/class.phpmailer.php";
require "phpmailer/class.smtp.php";

require_once("koneksi.php");

$date = date("d-m-Y");

$kontrak = "kontrak";

if ($cek>0){

try {

$mail      = new PHPMailer(true); //New instance, with exceptions enabled

$body     =   "<html>

<head>

</head>

<body>

<h2 align='center'><font face='Bradley Hand ITC'>Selamat Ulang Tahun<br />

".($row['nama'])." �

".($row['bagian'])."

<br />

".($date)."

</h2></font>

<h2 align='center'><font face='verdana'><b>

Seluruh Pengurus dan Karyawan<br />

PT. ANGIN RIBUT<br />

Mengucapkan Selamat Ulang Tahun Kepada ".($row['nama'])."<br />

Semoga Selalu diberikan keberkahan hidup <br />dan<br /> selalu berada                               dalam lindungan Tuhan YME.</b>

</font></h2>

</body></html>";

$mail->IsSMTP();                           // tell the class to use SMTP

$mail->SMTPAuth   = true;                  // enable SMTP authentication

//sesuaikan dengan host
$mail->SMTPSecure = "tls";

$mail->Port  = 587;                    // set the SMTP server port

$mail->Host  = "mail.tsuchiya-mfg.co.id"; // SMTP server

$mail->Username   = "aiti@tsuchiya.co.id";     // SMTP server username

$mail->Password   = "aiti123";            // SMTP server password
//sesuaikan dengan host

//$mail->IsSendmail();  // tell the class to use Sendmail

$mail->AddReplyTo("hakko@tsuchiya-mfg.co.id","IT System Development");

$mail->From   = "hakko@tsuchiya-mfg.co.id";

$mail->FromName   = "IT System Development";

//$to = $row[�EMAIL�];

$to = "agus@tsuchiya-mfg.co.id";

$bcc = "agus@tsuchiya-mfg.co.id";

$mail->AddAddress($to);

$mail->AddBCC($bcc);

$mail->Subject  = "Reminder Masa Kontrak Kurang dari 30 Hari";

//$mail->AltBody    = �To view the message, please use an HTML compatible email viewer!�;

// optional, comment out and test

//$mail->WordWrap   = 80; // set word wrap

$mail->MsgHTML($body);

$mail->IsHTML(true); // send as HTML

$mail->Send();

echo "Message has been sent";

} catch (phpmailerException $e) {

echo $e->errorMessage();

}

}

else {

echo "Tidak ada reminder hari ini.";

}
?>
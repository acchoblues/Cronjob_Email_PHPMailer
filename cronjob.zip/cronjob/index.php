<?php
include "koneksi.php";

if(mysqli_connect_errno()){
	echo 'Gagal melakukan koneksi ke Database : '.mysqli_connect_error();
}
    $date = date('Y-m-d');
    $kontrak = "kontrak";
	$query1="SELECT *,DATE_ADD(k1_finish, INTERVAL -30 DAY) as kontrak_habis, DATEDIFF(DATE_ADD(k1_finish, INTERVAL 0 DAY), CURDATE()) as selisih, DATEDIFF(DATE_ADD(k2_finish, INTERVAL 0 DAY), CURDATE()) as selisih1 FROM karyawan WHERE DATEDIFF(DATE_ADD(k1_finish, INTERVAL 0 DAY), CURDATE()) >= '1' AND DATEDIFF(DATE_ADD(k1_finish, INTERVAL 0 DAY), CURDATE()) <= '30' or DATEDIFF(DATE_ADD(k2_finish, INTERVAL 0 DAY), CURDATE()) >= '1' AND DATEDIFF(DATE_ADD(k2_finish, INTERVAL 0 DAY), CURDATE()) <= '30'";
    $daftar=mysqli_query($koneksi, $query1) or die (mysqli_error());
    
    $laporan="<h4><b>List Karyawan Yang Akan Habis Masa Kontraknya 30 Hari Lagi</b></h4>";
    $laporan .="<br/>";
	$laporan .="<table width=\"100%\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"0\">";
	$laporan .="<tr style=\"color: blue;\">";
	$laporan .="<td>NIK</td><td>Nama</td><td>Bagian</td>";
	$laporan .="</tr>";
	while($dataku=mysqli_fetch_object($daftar))
	{
		$laporan .="<tr>";
		$laporan .="<td>$dataku->nik</td><td>$dataku->nama</td><td>$dataku->bagian</td>";
		$laporan .="</tr>";
	}
	$laporan .="</table>";
    $laporan .="<h5><a href='http://tsuchiya-mfg.com/hrd'><b>Untuk detail klik link ini, untuk login gunakan User dan Pass = admin</b></a></h5>";
    
    require_once("phpmailer/class.phpmailer.php");
    require_once("phpmailer/class.smtp.php");
    
    $sendmail = new PHPMailer();
    $sendmail->setFrom('hakko@tsuchiya-mfg.co.id','Hakko Bio Richard'); //email pengirim
    $sendmail->addReplyTo('hakko@tsuchiya-mfg.co.id','Hakko Bio Richard'); //email replay
    $sendmail->addAddress('ridzy@tsuchiya-mfg.co.id','Agus Haryadi'); //email tujuan
    $sendmail->AddBCC('agus@tsuchiya-mfg.co.id');
    $sendmail->Subject = 'Karyawan Masa Kontak Habis 30 Hari Lagi'; //subjek email
    $sendmail->Body=$laporan; //isi pesan dalam format laporan
    $sendmail->isHTML(true);
	if(!$sendmail->Send()) 
	{
		echo "Email gagal dikirim : " . $sendmail->ErrorInfo;  
	} 
	else 
	{ 
		echo "Email berhasil terkirim!";  
	}
?>
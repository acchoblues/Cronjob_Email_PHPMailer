<?php

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "hrd";

$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if(mysqli_connect_errno()){
	echo 'Gagal melakukan koneksi ke Database : '.mysqli_connect_error();
}   

$today = date("Y-m-d");

$query  = "SELECT * FROM karyawan WHERE k1_finish LIKE '%$today%' AND STATUS='kontrak'";

$result = mysqli_query($koneksi, $query);

$row = mysqli_fetch_array($result);

$cek = mysqli_num_rows($result);

?>